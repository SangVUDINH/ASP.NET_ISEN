namespace Isen.Dotnet.Library.Model
{
    public abstract class BaseEntity
    {
        public int Id {get;set;}
    }
}