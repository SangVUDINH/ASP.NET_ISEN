﻿using System;
using Isen.Dotnet.Library;
using Isen.Dotnet.Library.Services;

namespace Isen.Dotnet.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
